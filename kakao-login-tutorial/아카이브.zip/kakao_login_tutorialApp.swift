//
//  kakao_login_tutorialApp.swift
//  kakao-login-tutorial
//
//  Created by 유욱현 on 2022/08/14.
//

import SwiftUI

@main
struct kakao_login_tutorialApp: App {
    
    @UIApplicationDelegateAdaptor var appDelegate : MyAppDelegate
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
